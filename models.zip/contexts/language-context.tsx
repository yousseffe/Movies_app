"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"
import Cookies from "js-cookie"

type Language = "en" | "ar"

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    "nav.home": "Home",
    "nav.movies": "Movies",
    "nav.people": "People",
    "nav.login": "Login",
    "nav.signup": "Sign Up",
    "nav.logout": "Logout",
    "nav.profile": "Profile",
    "nav.admin": "Admin",
    "nav.search": "Search",
    "nav.watchlist": "Watchlist",
    "nav.requests": "Requests",
    "home.hero.title": "Your Ultimate Movie Experience",
    "home.hero.subtitle": "Watch the latest movies and TV shows anytime, anywhere.",
    "home.hero.getStarted": "Get Started",
    "home.hero.browseMovies": "Browse Movies",
    "home.features.title": "Everything You Need for Movies",
    "home.features.subtitle": "Our platform offers a comprehensive set of features for movie lovers",
    "home.features.community": "Community",
    "home.features.community.desc": "Join discussions, share reviews, and connect with other movie enthusiasts.",
    "home.features.access": "Multi-device Access",
    "home.features.access.desc": "Watch your favorite movies on any device, anytime, anywhere.",
    "home.features.recommendations": "Personalized Recommendations",
    "home.features.recommendations.desc": "Get movie suggestions based on your preferences and viewing history.",
    "home.features.library": "Extensive Library",
    "home.features.library.desc": "Access thousands of movies from various genres, languages, and formats.",
    "home.cta.title": "Ready to Start Your Movie Journey?",
    "home.cta.subtitle":
      "Sign up today and get access to our extensive movie library, personalized recommendations, and more.",
    "home.cta.createAccount": "Create Account",
    "home.cta.signIn": "Sign In",
    "home.cta.alreadyHaveAccount": "Already have an account?",
    "footer.quickLinks": "Quick Links",
    "footer.legal": "Legal",
    "footer.contact": "Contact",
    "footer.rights": "All rights reserved.",
    "auth.login.title": "Login to your account",
    "auth.login.email": "Email",
    "auth.login.password": "Password",
    "auth.login.forgotPassword": "Forgot Password?",
    "auth.login.button": "Login",
    "auth.login.noAccount": "Don't have an account?",
    "auth.login.createAccount": "Create an account",
    "auth.register.title": "Create an account",
    "auth.register.name": "Name",
    "auth.register.email": "Email",
    "auth.register.password": "Password",
    "auth.register.confirmPassword": "Confirm Password",
    "auth.register.button": "Register",
    "auth.register.haveAccount": "Already have an account?",
    "auth.register.login": "Login",
    "auth.register.termsOfService": "Terms of Service",
    "auth.register.privacyPolicy": "Privacy Policy",
    "auth.register.agreeToTerms": "I agree to the {terms} and {privacy}",
    "auth.verify.title": "Verify your email",
    "auth.verify.message":
      "We've sent a verification link to your email. Please check your inbox and click the link to verify your account.",
    "auth.verify.resend": "Resend verification email",
    "auth.verify.back": "Back to login",
    "auth.forgotPassword.title": "Forgot Password",
    "auth.forgotPassword.message": "Enter your email address and we'll send you a link to reset your password.",
    "auth.forgotPassword.email": "Email",
    "auth.forgotPassword.button": "Send Reset Link",
    "auth.forgotPassword.back": "Back to login",
    "auth.resetPassword.title": "Reset Password",
    "auth.resetPassword.message": "Enter your new password below.",
    "auth.resetPassword.password": "New Password",
    "auth.resetPassword.confirmPassword": "Confirm New Password",
    "auth.resetPassword.button": "Reset Password",
    "auth.resetPassword.back": "Back to login",
    "movies.title": "Movies",
    "movies.search": "Search movies...",
    "movies.filter": "Filter",
    "movies.sort": "Sort",
    "movies.genre": "Genre",
    "movies.year": "Year",
    "movies.rating": "Rating",
    "movies.language": "Language",
    "movies.duration": "Duration",
    "movies.apply": "Apply Filters",
    "movies.reset": "Reset",
    "movies.noResults": "No movies found",
    "movies.tryAgain": "Please try different filters or search terms",
    "movie.details.cast": "Cast",
    "movie.details.crew": "Crew",
    "movie.details.director": "Director",
    "movie.details.writer": "Writer",
    "movie.details.genre": "Genre",
    "movie.details.duration": "Duration",
    "movie.details.releaseDate": "Release Date",
    "movie.details.rating": "Rating",
    "movie.details.language": "Language",
    "movie.details.country": "Country",
    "movie.details.plot": "Plot",
    "movie.details.trailer": "Trailer",
    "movie.details.watchNow": "Watch Now",
    "movie.details.addToWatchlist": "Add to Watchlist",
    "movie.details.removeFromWatchlist": "Remove from Watchlist",
    "movie.details.similar": "Similar Movies",
    "movie.details.reviews": "Reviews",
    "movie.details.writeReview": "Write a Review",
    "movie.details.noReviews": "No reviews yet",
    "movie.details.beFirst": "Be the first to review this movie",
    "watchlist.title": "My Watchlist",
    "watchlist.empty": "Your watchlist is empty",
    "watchlist.add": "Add movies to your watchlist",
    "watchlist.browse": "Browse Movies",
    "profile.title": "Profile",
    "profile.name": "Name",
    "profile.email": "Email",
    "profile.password": "Password",
    "profile.changePassword": "Change Password",
    "profile.save": "Save Changes",
    "profile.watchlist": "My Watchlist",
    "profile.reviews": "My Reviews",
    "profile.requests": "My Requests",
    "profile.logout": "Logout",
    "admin.dashboard.title": "Dashboard",
    "admin.dashboard.users": "Users",
    "admin.dashboard.movies": "Movies",
    "admin.dashboard.genres": "Genres",
    "admin.dashboard.requests": "Requests",
    "admin.dashboard.reviews": "Reviews",
    "admin.dashboard.analytics": "Analytics",
    "admin.movies.title": "Movies",
    "admin.movies.add": "Add Movie",
    "admin.movies.edit": "Edit Movie",
    "admin.movies.delete": "Delete Movie",
    "admin.movies.view": "View Movie",
    "admin.movies.search": "Search movies...",
    "admin.movies.filter": "Filter",
    "admin.movies.sort": "Sort",
    "admin.movies.genre": "Genre",
    "admin.movies.year": "Year",
    "admin.movies.rating": "Rating",
    "admin.movies.language": "Language",
    "admin.movies.duration": "Duration",
    "admin.movies.apply": "Apply Filters",
    "admin.movies.reset": "Reset",
    "admin.movies.noResults": "No movies found",
    "admin.movies.tryAgain": "Please try different filters or search terms",
    "admin.genres.title": "Genres",
    "admin.genres.add": "Add Genre",
    "admin.genres.edit": "Edit Genre",
    "admin.genres.delete": "Delete Genre",
    "admin.genres.search": "Search genres...",
    "admin.genres.noResults": "No genres found",
    "admin.genres.tryAgain": "Please try different search terms",
    "admin.requests.title": "Requests",
    "admin.requests.approve": "Approve",
    "admin.requests.reject": "Reject",
    "admin.requests.pending": "Pending",
    "admin.requests.approved": "Approved",
    "admin.requests.rejected": "Rejected",
    "admin.requests.search": "Search requests...",
    "admin.requests.filter": "Filter",
    "admin.requests.sort": "Sort",
    "admin.requests.status": "Status",
    "admin.requests.date": "Date",
    "admin.requests.user": "User",
    "admin.requests.apply": "Apply Filters",
    "admin.requests.reset": "Reset",
    "admin.requests.noResults": "No requests found",
    "admin.requests.tryAgain": "Please try different filters or search terms",
    "admin.users.title": "Users",
    "admin.users.add": "Add User",
    "admin.users.edit": "Edit User",
    "admin.users.delete": "Delete User",
    "admin.users.search": "Search users...",
    "admin.users.filter": "Filter",
    "admin.users.sort": "Sort",
    "admin.users.role": "Role",
    "admin.users.status": "Status",
    "admin.users.date": "Date",
    "admin.users.apply": "Apply Filters",
    "admin.users.reset": "Reset",
    "admin.users.noResults": "No users found",
    "admin.users.tryAgain": "Please try different filters or search terms",
    "admin.analytics.title": "Analytics",
    "admin.analytics.users": "Users",
    "admin.analytics.movies": "Movies",
    "admin.analytics.genres": "Genres",
    "admin.analytics.requests": "Requests",
    "admin.analytics.reviews": "Reviews",
    "admin.analytics.watchlist": "Watchlist",
    "admin.analytics.views": "Views",
    "admin.analytics.period": "Period",
    "admin.analytics.daily": "Daily",
    "admin.analytics.weekly": "Weekly",
    "admin.analytics.monthly": "Monthly",
    "admin.analytics.yearly": "Yearly",
    "admin.analytics.apply": "Apply",
    "admin.analytics.reset": "Reset",
    "admin.analytics.noData": "No data available",
    "admin.analytics.tryAgain": "Please try different filters or time period",
  },

  ar: {
    "nav.home": "الرئيسية",
    "nav.movies": "الأفلام",
    "nav.people": "الممثلون",
    "nav.login": "تسجيل الدخول",
    "nav.signup": "إنشاء حساب",
    "nav.logout": "تسجيل الخروج",
    "nav.profile": "الملف الشخصي",
    "nav.admin": "لوحة التحكم",
    "nav.search": "بحث",
    "nav.watchlist": "قائمة المشاهدة",
    "nav.requests": "الطلبات",
    "home.hero.title": "تجربة الأفلام المثالية",
    "home.hero.subtitle": "شاهد أحدث الأفلام والمسلسلات في أي وقت وأي مكان.",
    "home.hero.getStarted": "ابدأ الآن",
    "home.hero.browseMovies": "تصفح الأفلام",
    "home.features.title": "كل ما تحتاجه للأفلام",
    "home.features.subtitle": "توفر منصتنا مجموعة شاملة من الميزات لعشاق الأفلام",
    "home.features.community": "مجتمع",
    "home.features.community.desc": "انضم إلى المناقشات، شارك المراجعات، وتواصل مع عشاق الأفلام الآخرين.",
    "home.features.access": "الوصول عبر أجهزة متعددة",
    "home.features.access.desc": "شاهد أفلامك المفضلة على أي جهاز، في أي وقت، وفي أي مكان.",
    "home.features.recommendations": "توصيات مخصصة",
    "home.features.recommendations.desc": "احصل على اقتراحات أفلام بناءً على تفضيلاتك وتاريخ المشاهدة.",
    "home.features.library": "مكتبة واسعة",
    "home.features.library.desc": "الوصول إلى آلاف الأفلام من مختلف الأنواع واللغات والتنسيقات.",
    "home.cta.title": "هل أنت مستعد لبدء رحلة الأفلام الخاصة بك؟",
    "home.cta.subtitle": "سجل اليوم واحصل على وصول إلى مكتبة الأفلام الواسعة لدينا، والتوصيات المخصصة، والمزيد.",
    "home.cta.createAccount": "إنشاء حساب",
    "home.cta.signIn": "تسجيل الدخول",
    "home.cta.alreadyHaveAccount": "لديك حساب بالفعل؟",
    "footer.quickLinks": "روابط سريعة",
    "footer.legal": "قانوني",
    "footer.contact": "اتصل بنا",
    "footer.rights": "جميع الحقوق محفوظة.",
    "auth.login.title": "تسجيل الدخول إلى حسابك",
    "auth.login.email": "البريد الإلكتروني",
    "auth.login.password": "كلمة المرور",
    "auth.login.forgotPassword": "نسيت كلمة المرور؟",
    "auth.login.button": "تسجيل الدخول",
    "auth.login.noAccount": "ليس لديك حساب؟",
    "auth.login.createAccount": "إنشاء حساب",
    "auth.register.title": "إنشاء حساب",
    "auth.register.name": "الاسم",
    "auth.register.email": "البريد الإلكتروني",
    "auth.register.password": "كلمة المرور",
    "auth.register.confirmPassword": "تأكيد كلمة المرور",
    "auth.register.button": "تسجيل",
    "auth.register.haveAccount": "لديك حساب بالفعل؟",
    "auth.register.login": "تسجيل الدخول",
    "auth.register.termsOfService": "شروط الخدمة",
    "auth.register.privacyPolicy": "سياسة الخصوصية",
    "auth.register.agreeToTerms": "أوافق على {terms} و {privacy}",
    "movies.title": "الأفلام",
    "movies.search": "البحث عن الأفلام...",
    "movies.filter": "تصفية",
    "movies.sort": "ترتيب",
    "movies.genre": "النوع",
    "movies.year": "السنة",
    "movies.rating": "التقييم",
    "movies.language": "اللغة",
    "movies.duration": "المدة",
    "movies.apply": "تطبيق الفلاتر",
    "movies.reset": "إعادة تعيين",
    "movies.noResults": "لم يتم العثور على أفلام",
    "movies.tryAgain": "يرجى تجربة فلاتر مختلفة أو مصطلحات بحث مختلفة",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const [language, setLanguageState] = useState<Language>("en")

  useEffect(() => {
    const savedLanguage = Cookies.get("language") as Language
    if (savedLanguage) {
      setLanguageState(savedLanguage)
      document.documentElement.lang = savedLanguage
      document.documentElement.dir = savedLanguage === "ar" ? "rtl" : "ltr"
    }
  }, [])

  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    document.documentElement.lang = lang
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"
    Cookies.set("language", lang)

    // Refresh the page to apply RTL/LTR changes
    if (pathname) {
      router.refresh()
    }
  }

  const t = (key: string): string => {
    return translations[language][key as keyof (typeof translations)[typeof language]] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

