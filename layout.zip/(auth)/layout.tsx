"use client"

import type React from "react"
import { Inter, Amiri } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { AuthProvider } from "@/components/auth-provider"
import { LanguageProvider, useLanguage } from "@/contexts/language-context"
import { Analytics } from "@vercel/analytics/react"
import { SpeedInsights } from "@vercel/speed-insights/next"
import "../globals.css"
import { Link } from "lucide-react"
import { LanguageSwitcher } from "@/components/language-switcher"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"




export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { t, language } = useLanguage()
  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center">
            <div className="relative h-10 w-10 mr-2 rounded-full bg-primary text-white flex items-center justify-center">
              <span className="text-xl font-bold">{language === "en" ? "S" : "س"}</span>
            </div>
            <span className="text-xl font-bold">{language === "en" ? "Sanapel" : "سنابل"}</span>
          </Link>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            <ThemeToggle />
            
              <div className="hidden md:flex md:gap-4">
                <Button variant="ghost" asChild>
                  <Link href="/login">{t("nav.login")}</Link>
                </Button>
                <Button asChild>
                  <Link href="/register">{t("nav.signup")}</Link>
                </Button>
              </div>
            
          </div>
        </div>
      </header>
        {children}
        </>
  )
}


